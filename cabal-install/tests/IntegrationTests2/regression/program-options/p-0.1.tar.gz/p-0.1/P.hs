module P where

p = "hello"
